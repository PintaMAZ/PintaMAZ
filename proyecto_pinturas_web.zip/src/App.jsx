
import React, { useState } from 'react'

export default function App() {
  const [metros, setMetros] = useState('')
  const [color, setColor] = useState('Blanco')
  const [extras, setExtras] = useState([])
  const [precio, setPrecio] = useState(null)

  const calcular = () => {
    let base = metros * 15000
    if (extras.includes('techos')) base += 100000
    if (extras.includes('closets')) base += 200000
    if (extras.includes('paredes')) base += 50000
    setPrecio(base)
  }

  const enviarWhatsApp = () => {
    const url = `https://wa.me/573187703978?text=Hola! Quiero cotizar una pintada de ${metros}m2 en color ${color}. Extras: ${extras.join(', ')}. Precio estimado: $${precio}`
    window.open(url, '_blank')
  }

  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1>Pinturas Arriendo</h1>
      <p>Cotiza en segundos la pintada de tu inmueble</p>

      <label>Metros cuadrados: </label>
      <input value={metros} onChange={e => setMetros(e.target.value)} />
      <br />

      <label>Color: </label>
      <select value={color} onChange={e => setColor(e.target.value)}>
        <option>Blanco</option>
        <option>Beige</option>
        <option>Gris</option>
      </select>
      <br />

      <label>Extras: </label>
      <br />
      <input type="checkbox" value="techos" onChange={e => setExtras(prev => e.target.checked ? [...prev, 'techos'] : prev.filter(x => x !== 'techos'))}/> Techos
      <br />
      <input type="checkbox" value="closets" onChange={e => setExtras(prev => e.target.checked ? [...prev, 'closets'] : prev.filter(x => x !== 'closets'))}/> Closets
      <br />
      <input type="checkbox" value="paredes" onChange={e => setExtras(prev => e.target.checked ? [...prev, 'paredes'] : prev.filter(x => x !== 'paredes'))}/> Paredes especiales
      <br />

      <button onClick={calcular}>Calcular precio</button>

      {precio && (
        <div>
          <h2>Precio estimado: ${precio}</h2>
          <button onClick={enviarWhatsApp}>Enviar a WhatsApp</button>
        </div>
      )}
    </div>
  )
}
